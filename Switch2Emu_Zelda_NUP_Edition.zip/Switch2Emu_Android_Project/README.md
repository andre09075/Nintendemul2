# Switch2Emu - Proyecto Base para Android (C++20 / NDK / Jetpack Compose)

## Estado Técnico Real del Proyecto
Siguiendo estrictos principios de ingeniería de software:
- **Implementado y funcional:**
  - Interfaz nativa en Android con Jetpack Compose (Biblioteca, Controles, Configuración y Diagnóstico).
  - Puente nativo JNI (`libswitch2emu.so`) en C++20.
  - Reserva real de memoria virtual unificada de 12 GB (`mmap` con `MAP_NORESERVE`) para Fastmem en arquitecturas ARM64 (`arm64-v8a`).
  - Esqueleto modular (`core`, `video_core`, `audio_core`, `input_common`).
- **No implementado (Limitaciones técnicas y legales):**
  - Desencriptación de ROMs comerciales y carga de binarios de Horizon OS 2.
  - Traducción de shaders propietarios NVN2 a SPIR-V (Vulkan).
  - Ejecución de juegos comerciales.

## Cómo generar el archivo `.apk` instalable

### Opción 1: Automáticamente en la nube (Sin instalar nada en tu PC/Móvil)
1. Sube el contenido de este ZIP a un repositorio de **GitHub**.
2. Ve a la pestaña **Actions** de tu repositorio.
3. El flujo de trabajo `.github/workflows/build_apk.yml` compilará automáticamente el código C++ con el Android NDK y empaquetará el APK.
4. Descarga el archivo `Switch2Emu-debug-apk` generado en la sección **Artifacts**.

### Opción 2: Localmente con Android Studio
1. Abre la carpeta del proyecto en **Android Studio Iguana (o superior)**.
2. Desde el *SDK Manager*, instala **NDK (Side by side) 26.1.10909125** y **CMake 3.22.1**.
3. En el menú superior, selecciona **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. El archivo instalable se generará en `app/build/outputs/apk/debug/app-debug.apk`.
