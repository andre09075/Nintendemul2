#include <jni.h>
#include <memory>
#include <string>
#include <vector>
#include "core/system.h"

static std::unique_ptr<Core::System> g_system;
static std::string g_last_status = "Núcleo inicializado con soporte NCE en el procesador de tu teléfono.";

extern "C" JNIEXPORT jboolean JNICALL
Java_com_emu_switch2_MainActivity_initializeEmulator(JNIEnv* /*env*/, jobject /*thiz*/) {
    g_system = std::make_unique<Core::System>();
    return g_system->Initialize() ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_emu_switch2_MainActivity_getHardwareSpecSummary(JNIEnv* env, jobject /*thiz*/) {
    if (!g_system) return env->NewStringUTF("No inicializado.");
    std::string summary = g_system->GetHardwareSummary();
    return env->NewStringUTF(summary.c_str());
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_emu_switch2_MainActivity_getLastStatus(JNIEnv* env, jobject /*thiz*/) {
    return env->NewStringUTF(g_last_status.c_str());
}

extern "C" JNIEXPORT jint JNICALL
Java_com_emu_switch2_MainActivity_loadGameBytes(JNIEnv* env, jobject /*thiz*/, jbyteArray fileBytes, jstring fileName) {
    if (!g_system || !fileBytes) return -2;
    jsize len = env->GetArrayLength(fileBytes);
    jbyte* body = env->GetByteArrayElements(fileBytes, nullptr);
    const char* name_str = env->GetStringUTFChars(fileName, nullptr);

    int res = g_system->LoadExecutableFromBytes(
        reinterpret_cast<const uint8_t*>(body),
        static_cast<size_t>(len),
        std::string(name_str),
        g_last_status
    );

    env->ReleaseStringUTFChars(fileName, name_str);
    env->ReleaseByteArrayElements(fileBytes, body, JNI_ABORT);
    return res;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_emu_switch2_MainActivity_startEmbeddedHomebrew(JNIEnv* /*env*/, jobject /*thiz*/) {
    if (!g_system) return JNI_FALSE;
    return g_system->LoadEmbeddedHomebrewTest(g_last_status) ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT jintArray JNICALL
Java_com_emu_switch2_MainActivity_stepEmulatorFrame(JNIEnv* env, jobject /*thiz*/, jint width, jint height, jlong buttons) {
    int total_pixels = width * height;
    jintArray result = env->NewIntArray(total_pixels);
    if (!g_system || !result) return result;

    std::vector<uint32_t> framebuffer(total_pixels, 0xFF101018);
    g_system->RunSingleFrame(framebuffer.data(), width, height, static_cast<uint64_t>(buttons));
    env->SetIntArrayRegion(result, 0, total_pixels, reinterpret_cast<const jint*>(framebuffer.data()));
    return result;
}

extern "C" JNIEXPORT void JNICALL
Java_com_emu_switch2_MainActivity_setConfigOption(JNIEnv* env, jobject /*thiz*/, jstring key, jstring value) {
    if (!g_system) return;
    const char* k = env->GetStringUTFChars(key, nullptr);
    const char* v = env->GetStringUTFChars(value, nullptr);
    g_system->SetConfig(k, v);
    env->ReleaseStringUTFChars(key, k);
    env->ReleaseStringUTFChars(value, v);
}

extern "C" JNIEXPORT void JNICALL
Java_com_emu_switch2_MainActivity_stopEmulator(JNIEnv* /*env*/, jobject /*thiz*/) {
    if (g_system) {
        g_system->Shutdown();
        g_system.reset();
    }
}
