// Backend de inicialización Vulkan para traducción futura de NVN2
#include <vulkan/vulkan.h>

namespace VideoCore {
bool CheckVulkanSupport() {
    uint32_t instance_version = 0;
    return vkEnumerateInstanceVersion(&instance_version) == VK_SUCCESS;
}
} // namespace VideoCore
