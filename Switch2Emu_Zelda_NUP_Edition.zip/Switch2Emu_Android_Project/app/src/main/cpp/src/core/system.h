#pragma once
#include <string>
#include <memory>
#include <vector>
#include <cstdint>
#include <unordered_map>

namespace Core {

struct Arm64CpuState {
    uint64_t x[31]{0};
    uint64_t sp{0};
    uint64_t pc{0};
    uint32_t pstate{0};
    uint64_t instructions_executed{0};
    bool nce_active{false};
};

struct HostSocCapabilities {
    int cpu_cores{0};
    std::string cpu_arch;
    bool supports_arm64_nce{false};
    bool supports_asimd{false};
};

class MemoryManager {
public:
    bool Initialize(size_t size_bytes);
    void Shutdown();
    bool CommitPages(uint64_t offset, size_t size, int prot);
    bool WriteBlock(uint64_t offset, const void* src, size_t size);
    bool ReadBlock(uint64_t offset, void* dst, size_t size) const;
    uint8_t* GetBasePtr() const { return static_cast<uint8_t*>(base_ptr_); }
    size_t GetAllocatedVirtualSize() const { return virtual_size_; }
private:
    void* base_ptr_ = nullptr;
    size_t virtual_size_ = 0;
};

class BinaryLoader {
public:
    enum class BinaryFormat {
        Unknown,
        Homebrew_NRO64,
        Executable_ELF64,
        Nintendo3DS_Remake_CCI_3DS,
        Zip_Or_NUP_Package,
        Nintendo64_Original_Z64,
        Encrypted_Switch_NSP_XCI
    };

    static BinaryFormat IdentifyFormat(const uint8_t* data, size_t size, const std::string& filename);
    static bool LoadIntoMemory(const uint8_t* data, size_t size, const std::string& filename, MemoryManager* memory, uint64_t& out_entry_point, std::string& out_log);
};

class Arm64Executor {
public:
    explicit Arm64Executor(MemoryManager* memory);
    void Reset(uint64_t entry_pc, uint64_t stack_top, bool enable_nce);
    void StepFrame(uint32_t* rgba_framebuffer, int width, int height, uint64_t gamepad_buttons);
    const Arm64CpuState& GetState() const { return state_; }
private:
    void ExecuteInstruction(uint32_t inst);
    void HandleSvc(uint16_t imm);
    MemoryManager* memory_;
    Arm64CpuState state_;
    uint32_t frame_counter_ = 0;
};

class System {
public:
    System();
    ~System();

    bool Initialize();
    int LoadExecutableFromBytes(const uint8_t* data, size_t size, const std::string& filename, std::string& out_status);
    bool LoadEmbeddedHomebrewTest(std::string& out_status);
    void RunSingleFrame(uint32_t* out_rgba_pixels, int width, int height, uint64_t buttons);
    void SetConfig(const std::string& key, const std::string& value);
    std::string GetHardwareSummary() const;
    void Shutdown();

private:
    void DetectHostHardware();
    std::unique_ptr<MemoryManager> memory_;
    std::unique_ptr<Arm64Executor> cpu_executor_;
    HostSocCapabilities host_caps_;
    std::unordered_map<std::string, std::string> config_;
    bool initialized_ = false;
    bool binary_loaded_ = false;
};

} // namespace Core
