#include "core/system.h"
#include <sys/mman.h>
#include <cstring>

namespace Core {

bool MemoryManager::Initialize(size_t size_bytes) {
    base_ptr_ = mmap(nullptr, size_bytes, PROT_NONE, MAP_PRIVATE | MAP_ANONYMOUS | MAP_NORESERVE, -1, 0);
    if (base_ptr_ == MAP_FAILED) {
        base_ptr_ = nullptr;
        return false;
    }
    virtual_size_ = size_bytes;
    return true;
}

bool MemoryManager::CommitPages(uint64_t offset, size_t size, int prot) {
    if (!base_ptr_ || offset + size > virtual_size_) return false;
    uint64_t page_mask = ~0xFFFULL;
    uint64_t aligned_offset = offset & page_mask;
    size_t aligned_size = ((offset + size + 0xFFFULL) & page_mask) - aligned_offset;
    return mprotect(static_cast<uint8_t*>(base_ptr_) + aligned_offset, aligned_size, prot) == 0;
}

bool MemoryManager::WriteBlock(uint64_t offset, const void* src, size_t size) {
    if (!base_ptr_ || offset + size > virtual_size_) return false;
    if (!CommitPages(offset, size, PROT_READ | PROT_WRITE)) return false;
    std::memcpy(static_cast<uint8_t*>(base_ptr_) + offset, src, size);
    return true;
}

bool MemoryManager::ReadBlock(uint64_t offset, void* dst, size_t size) const {
    if (!base_ptr_ || offset + size > virtual_size_) return false;
    std::memcpy(dst, static_cast<const uint8_t*>(base_ptr_) + offset, size);
    return true;
}

void MemoryManager::Shutdown() {
    if (base_ptr_ && virtual_size_ > 0) {
        munmap(base_ptr_, virtual_size_);
        base_ptr_ = nullptr;
        virtual_size_ = 0;
    }
}

} // namespace Core
