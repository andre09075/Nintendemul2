#include "core/system.h"
#include <sstream>
#include <cstring>
#include <unistd.h>
#include <sched.h>

namespace Core {

System::System()
    : memory_(std::make_unique<MemoryManager>()),
      cpu_executor_(std::make_unique<Arm64Executor>(memory_.get())) {}

System::~System() {
    Shutdown();
}

void System::DetectHostHardware() {
    host_caps_.cpu_cores = static_cast<int>(sysconf(_SC_NPROCESSORS_ONLN));
#if defined(__aarch64__)
    host_caps_.cpu_arch = "ARM64 Nativo (AArch64)";
    host_caps_.supports_arm64_nce = true;
    host_caps_.supports_asimd = true;
#else
    host_caps_.cpu_arch = "Arquitectura no-ARM64 (Fallback Intérprete)";
    host_caps_.supports_arm64_nce = false;
    host_caps_.supports_asimd = false;
#endif

    // Anclar el hilo de ejecución principal a los núcleos Prime/Performance del procesador del teléfono
    if (host_caps_.cpu_cores >= 4) {
        cpu_set_t cpuset;
        CPU_ZERO(&cpuset);
        // En SoCs Android (Snapdragon / Dimensity), los últimos núcleos son los Cortex-X / Big cores
        for (int i = host_caps_.cpu_cores / 2; i < host_caps_.cpu_cores; ++i) {
            CPU_SET(i, &cpuset);
        }
        sched_setaffinity(0, sizeof(cpu_set_t), &cpuset);
    }
}

bool System::Initialize() {
    DetectHostHardware();
    constexpr size_t kSwitch2RamSize = 12ULL * 1024ULL * 1024ULL * 1024ULL;
    if (!memory_->Initialize(kSwitch2RamSize)) {
        return false;
    }
    initialized_ = true;
    return true;
}

bool System::LoadEmbeddedHomebrewTest(std::string& out_status) {
    if (!initialized_) return false;

    std::vector<uint8_t> nro_binary(0x1000, 0);
    uint32_t magic = 0x304F524E; // "NRO0"
    uint32_t size = 0x1000;
    uint32_t text_offset = 0x80;
    uint32_t text_size = 0x200;

    std::memcpy(nro_binary.data() + 0x10, &magic, 4);
    std::memcpy(nro_binary.data() + 0x18, &size, 4);
    std::memcpy(nro_binary.data() + 0x20, &text_offset, 4);
    std::memcpy(nro_binary.data() + 0x24, &text_size, 4);

    uint32_t program_code[] = {
        0xD2800801, // MOVZ X1, #64
        0xD2800402, // MOVZ X2, #32
        0x91000821, // ADD X1, X1, #2
        0x91000442, // ADD X2, X2, #1
        0xD4000161  // SVC #0x0B
    };
    std::memcpy(nro_binary.data() + text_offset, program_code, sizeof(program_code));

    uint64_t entry = 0;
    if (BinaryLoader::LoadIntoMemory(nro_binary.data(), nro_binary.size(), "triforce_test.nro", memory_.get(), entry, out_status)) {
        cpu_executor_->Reset(entry, 0x70000000ULL, host_caps_.supports_arm64_nce);
        binary_loaded_ = true;
        return true;
    }
    return false;
}

int System::LoadExecutableFromBytes(const uint8_t* data, size_t size, const std::string& filename, std::string& out_status) {
    if (!initialized_) {
        out_status = "Sistema no inicializado.";
        return -2;
    }
    uint64_t entry_point = 0;
    if (BinaryLoader::LoadIntoMemory(data, size, filename, memory_.get(), entry_point, out_status)) {
        cpu_executor_->Reset(entry_point, 0x70000000ULL, host_caps_.supports_arm64_nce);
        binary_loaded_ = true;
        return 0;
    }
    return -1;
}

void System::RunSingleFrame(uint32_t* out_rgba_pixels, int width, int height, uint64_t buttons) {
    if (!initialized_ || !binary_loaded_) return;
    cpu_executor_->StepFrame(out_rgba_pixels, width, height, buttons);
}

void System::SetConfig(const std::string& key, const std::string& value) {
    config_[key] = value;
}

std::string System::GetHardwareSummary() const {
    std::ostringstream ss;
    const auto& st = cpu_executor_->GetState();
    ss << "=== PROCESADOR DEL TELÉFONO DETECTADO (NCE HOST) ===\n"
       << "• Arquitectura Host: " << host_caps_.cpu_arch << "\n"
       << "• Núcleos Físicos Activos: " << host_caps_.cpu_cores << " núcleos (Hilo anclado a núcleos Prime/Big de alto rendimiento)\n"
       << "• Ejecución Nativa Directa (ARM64 NCE): " << (host_caps_.supports_arm64_nce ? "HABILITADA (Sin sobrecarga de traducción)" : "Deshabilitada") << "\n"
       << "• Instrucciones Vectoriales NEON/ASIMD: " << (host_caps_.supports_asimd ? "Soportadas" : "No") << "\n\n"
       << "=== ESTADO DEL NÚCLEO EMULADO ===\n"
       << "• RAM Virtual Unificada: 12 GB LPDDR5X (Fastmem mmap activa)\n"
       << "• Contador de Programa (PC): 0x" << std::hex << st.pc << std::dec << "\n"
       << "• Instrucciones AArch64 Ejecutadas: " << st.instructions_executed;
    return ss.str();
}

void System::Shutdown() {
    if (initialized_) {
        memory_->Shutdown();
        initialized_ = false;
        binary_loaded_ = false;
    }
}

} // namespace Core
