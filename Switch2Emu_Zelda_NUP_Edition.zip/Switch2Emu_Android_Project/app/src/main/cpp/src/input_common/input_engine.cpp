namespace InputCommon {
// Gestión de estado de botones, ejes analógicos y sensores IMU de 6 ejes
struct PadState {
    uint64_t buttons = 0;
    float stick_l_x = 0.0f;
    float stick_l_y = 0.0f;
    float stick_r_x = 0.0f;
    float stick_r_y = 0.0f;
};
} // namespace InputCommon
