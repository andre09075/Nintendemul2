namespace AudioCore {
// Esqueleto de salida de audio de baja latencia (preparado para AAudio / Oboe en Android)
void InitializeAudioSink() {}
} // namespace AudioCore
