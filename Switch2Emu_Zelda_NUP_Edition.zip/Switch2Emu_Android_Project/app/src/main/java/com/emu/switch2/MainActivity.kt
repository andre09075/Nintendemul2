package com.emu.switch2

import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {

    companion object {
        init {
            System.loadLibrary("switch2emu")
        }
    }

    external fun initializeEmulator(): Boolean
    external fun getHardwareSpecSummary(): String
    external fun getLastStatus(): String
    external fun loadGameBytes(fileBytes: ByteArray, fileName: String): Int
    external fun startEmbeddedHomebrew(): Boolean
    external fun stepEmulatorFrame(width: Int, height: Int, buttons: Long): IntArray
    external fun setConfigOption(key: String, value: String)
    external fun stopEmulator()

    private fun resolveFileName(uri: Uri): String {
        var name = "archivo_desconocido"
        contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (nameIndex != -1 && cursor.moveToFirst()) {
                name = cursor.getString(nameIndex)
            }
        }
        return name
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        initializeEmulator()

        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                var selectedTab by remember { mutableStateOf(0) }
                var statusText by remember { mutableStateOf(getLastStatus()) }
                var hwSummary by remember { mutableStateOf(getHardwareSpecSummary()) }
                var isRunningHomebrew by remember { mutableStateOf(false) }
                var buttonState by remember { mutableStateOf(0L) }
                var frameBitmap by remember { mutableStateOf<Bitmap?>(null) }

                LaunchedEffect(isRunningHomebrew) {
                    val width = 160
                    val height = 90
                    val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                    while (isRunningHomebrew) {
                        val pixels = stepEmulatorFrame(width, height, buttonState)
                        bmp.setPixels(pixels, 0, width, 0, 0, width, height)
                        frameBitmap = bmp.copy(Bitmap.Config.ARGB_8888, false)
                        hwSummary = getHardwareSpecSummary()
                        delay(16L)
                    }
                }

                val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
                    uri?.let {
                        try {
                            val fileName = resolveFileName(it)
                            contentResolver.openInputStream(it)?.use { inputStream ->
                                // Leemos hasta 32 MB en el buffer para analizar cabeceras y cargar NRO64/ELF64 desde ContentResolver de Android
                                val maxBytes = 32 * 1024 * 1024
                                val bytes = inputStream.readNBytes(maxBytes)
                                val res = loadGameBytes(bytes, fileName)
                                statusText = getLastStatus()
                                if (res == 0) {
                                    isRunningHomebrew = true
                                    selectedTab = 1
                                }
                            }
                        } catch (e: Exception) {
                            statusText = "Error al leer archivo desde Android Storage: ${e.message}"
                        }
                    }
                }

                Row(modifier = Modifier.fillMaxSize().background(Color(0xFF121212))) {
                    Column(
                        modifier = Modifier.width(215.dp).fillMaxHeight().background(Color(0xFF1E1E24)).padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text("SWITCH 2 EMU", fontSize = 19.sp, fontWeight = FontWeight.Bold, color = Color(0xFFE60012))
                        Text("ARM64 NCE + Zelda Loader", fontSize = 12.sp, color = Color(0xFFFFD700))

                        Button(onClick = { selectedTab = 0 }, modifier = Modifier.fillMaxWidth()) { Text("Cargar Zelda / ROM") }
                        Button(onClick = { selectedTab = 1 }, modifier = Modifier.fillMaxWidth()) { Text("Pantalla en Vivo") }
                        Button(onClick = { selectedTab = 2 }, modifier = Modifier.fillMaxWidth()) { Text("CPU de tu Teléfono") }
                    }

                    Column(modifier = Modifier.fillMaxSize().padding(20.dp)) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF25252E)),
                            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
                        ) {
                            Text(statusText, color = Color(0xFFFFB74D), fontSize = 13.sp, modifier = Modifier.padding(12.dp))
                        }

                        when (selectedTab) {
                            0 -> {
                                Text("Cargador Directo con Aceleración NCE del Teléfono", fontSize = 19.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                Spacer(modifier = Modifier.height(10.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Button(onClick = { filePicker.launch(arrayOf("*/*")) }) {
                                        Text("📂 Seleccionar tu archivo de Zelda descargado")
                                    }
                                    OutlinedButton(onClick = {
                                        if (startEmbeddedHomebrew()) {
                                            statusText = getLastStatus()
                                            isRunningHomebrew = true
                                            selectedTab = 1
                                        }
                                    }) {
                                        Text("▶ Demo Trifuerza ARM64")
                                    }
                                }
                                Spacer(modifier = Modifier.height(14.dp))
                                Text(
                                    "• Lectura directa corregida: Ahora abre cualquier archivo de tu almacenamiento interno de Android vía ContentResolver.\n" +
                                    "• Si tu archivo es el port ARM64 ('soh.nro' de Ship of Harkinian), se cargará usando NCE nativo en los núcleos de alto rendimiento de tu teléfono.\n" +
                                    "• Si tu archivo es de 3DS (.3ds/.cci), N64 (.z64) o un contenedor .nup, el analizador te indicará exactamente qué arquitectura tiene.",
                                    color = Color.LightGray, fontSize = 13.sp
                                )
                            }
                            1 -> {
                                Row(
                                    modifier = Modifier.fillMaxSize(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Button(onClick = { buttonState = buttonState xor 0x01L }) { Text("▲") }
                                        Row {
                                            Button(onClick = { buttonState = buttonState xor 0x04L }) { Text("◀") }
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Button(onClick = { buttonState = buttonState xor 0x08L }) { Text("▶") }
                                        }
                                        Button(onClick = { buttonState = buttonState xor 0x02L }) { Text("▼") }
                                    }

                                    Box(
                                        modifier = Modifier.weight(1f).fillMaxHeight().padding(horizontal = 16.dp).background(Color.Black),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        frameBitmap?.let { bmp ->
                                            Image(
                                                bitmap = bmp.asImageBitmap(),
                                                contentDescription = "Framebuffer",
                                                modifier = Modifier.fillMaxSize(),
                                                contentScale = ContentScale.Fit
                                            )
                                        } ?: Text("Selecciona tu archivo o inicia la Demo Trifuerza", color = Color.Gray)
                                    }

                                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Button(onClick = { buttonState = buttonState xor 0x10L }) { Text("Botón A") }
                                        Button(
                                            onClick = { isRunningHomebrew = !isRunningHomebrew },
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE60012))
                                        ) {
                                            Text(if (isRunningHomebrew) "Pausar" else "Reanudar")
                                        }
                                    }
                                }
                            }
                            2 -> {
                                Text("Aceleración por Hardware del Teléfono (Host SoC)", fontSize = 19.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(hwSummary, color = Color(0xFF81C784), fontSize = 14.sp)
                            }
                        }
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        stopEmulator()
    }
}
